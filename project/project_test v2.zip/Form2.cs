﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace project_test
{
    public partial class Form2 : Form
    {
        Form1 frm1;
        private SerialPort sp = new SerialPort();
        //btnAuto.Checked = true;


        public Form2()
        {
            
            InitializeComponent();
            sp.PortName = "COM3";

            sp.BaudRate = 9600;

            sp.Open();
        }

        public Form2(Form1 _form)
        {
            InitializeComponent();
            frm1 = _form;
        }




        private void btnAuto_CheckedChanged(object sender, EventArgs e)
        {
            if (btnAuto.Checked == true)
            {
                groupBox_Manual.Enabled = false;
            }
            else
            {
                groupBox_Manual.Enabled = true;
            }
        }

        
       private void btnPumpOn_Click(object sender, EventArgs e)
        {
            if (sp.IsOpen)
            {
                sp.WriteLine("#P:1");
            }
        }
        


        private void btnPumpOff_Click(object sender, EventArgs e)
        {
            if (sp.IsOpen)
            {
                sp.WriteLine("#P:0");
            }
        }

        private void btnPumpOn_Click_1(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnManual_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}



