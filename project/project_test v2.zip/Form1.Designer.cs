﻿
namespace project_test
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbComPort = new System.Windows.Forms.ComboBox();
            this.cmbBaudRate = new System.Windows.Forms.ComboBox();
            this.btnCon = new System.Windows.Forms.Button();
            this.btnDBcon = new System.Windows.Forms.Button();
            this.btnManual = new System.Windows.Forms.RadioButton();
            this.btnAuto = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusbar = new System.Windows.Forms.StatusStrip();
            this.Status = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Data_listBox = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox_Manual = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnPumpOff = new System.Windows.Forms.Button();
            this.btnPumpOn = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_FanOff = new System.Windows.Forms.Button();
            this.btn_Fanall = new System.Windows.Forms.Button();
            this.btn_Fan2 = new System.Windows.Forms.Button();
            this.btn_Fan1 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnLamp3 = new System.Windows.Forms.Button();
            this.btnLamp2 = new System.Windows.Forms.Button();
            this.btnLampOff = new System.Windows.Forms.Button();
            this.btnLamp1 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label38 = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblTodayText = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.lblHumi_in = new System.Windows.Forms.Label();
            this.lblTemp_in = new System.Windows.Forms.Label();
            this.TempProgressBar = new CircularProgressBar.CircularProgressBar();
            this.HumiProgressBar = new CircularProgressBar.CircularProgressBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblLight_in = new System.Windows.Forms.Label();
            this.LightProgressBar = new CircularProgressBar.CircularProgressBar();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.lblWaterTemp = new System.Windows.Forms.Label();
            this.TankTempProgressBar1 = new CircularProgressBar.CircularProgressBar();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.metroListView1 = new MetroFramework.Controls.MetroListView();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picDBoff = new System.Windows.Forms.PictureBox();
            this.picDBon = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Water_Level_Bar = new VerticalProgressBar();
            this.label9 = new System.Windows.Forms.Label();
            this.statusbar.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox_Manual.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDBoff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDBon)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // cmbComPort
            // 
            resources.ApplyResources(this.cmbComPort, "cmbComPort");
            this.cmbComPort.FormattingEnabled = true;
            this.cmbComPort.Name = "cmbComPort";
            // 
            // cmbBaudRate
            // 
            resources.ApplyResources(this.cmbBaudRate, "cmbBaudRate");
            this.cmbBaudRate.FormattingEnabled = true;
            this.cmbBaudRate.Name = "cmbBaudRate";
            // 
            // btnCon
            // 
            resources.ApplyResources(this.btnCon, "btnCon");
            this.btnCon.ForeColor = System.Drawing.Color.Black;
            this.btnCon.Name = "btnCon";
            this.btnCon.UseVisualStyleBackColor = true;
            this.btnCon.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDBcon
            // 
            resources.ApplyResources(this.btnDBcon, "btnDBcon");
            this.btnDBcon.ForeColor = System.Drawing.Color.Black;
            this.btnDBcon.Name = "btnDBcon";
            this.btnDBcon.UseVisualStyleBackColor = true;
            this.btnDBcon.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnManual
            // 
            resources.ApplyResources(this.btnManual, "btnManual");
            this.btnManual.ForeColor = System.Drawing.Color.White;
            this.btnManual.Name = "btnManual";
            this.btnManual.TabStop = true;
            this.btnManual.UseVisualStyleBackColor = true;
            // 
            // btnAuto
            // 
            resources.ApplyResources(this.btnAuto, "btnAuto");
            this.btnAuto.ForeColor = System.Drawing.Color.White;
            this.btnAuto.Name = "btnAuto";
            this.btnAuto.TabStop = true;
            this.btnAuto.UseVisualStyleBackColor = true;
            this.btnAuto.CheckedChanged += new System.EventHandler(this.btnAuto_CheckedChanged);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // statusbar
            // 
            this.statusbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Status});
            resources.ApplyResources(this.statusbar, "statusbar");
            this.statusbar.Name = "statusbar";
            // 
            // Status
            // 
            this.Status.ForeColor = System.Drawing.Color.White;
            this.Status.Name = "Status";
            resources.ApplyResources(this.Status, "Status");
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Data_listBox);
            this.groupBox5.ForeColor = System.Drawing.Color.WhiteSmoke;
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // Data_listBox
            // 
            this.Data_listBox.ForeColor = System.Drawing.Color.Black;
            this.Data_listBox.FormattingEnabled = true;
            resources.ApplyResources(this.Data_listBox, "Data_listBox");
            this.Data_listBox.Name = "Data_listBox";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox_Manual);
            this.groupBox3.Controls.Add(this.btnManual);
            this.groupBox3.Controls.Add(this.btnAuto);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // groupBox_Manual
            // 
            this.groupBox_Manual.Controls.Add(this.groupBox6);
            this.groupBox_Manual.Controls.Add(this.groupBox8);
            this.groupBox_Manual.Controls.Add(this.groupBox7);
            resources.ApplyResources(this.groupBox_Manual, "groupBox_Manual");
            this.groupBox_Manual.Name = "groupBox_Manual";
            this.groupBox_Manual.TabStop = false;
            this.groupBox_Manual.Enter += new System.EventHandler(this.groupBox9_Enter_1);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnPumpOff);
            this.groupBox6.Controls.Add(this.btnPumpOn);
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // btnPumpOff
            // 
            this.btnPumpOff.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnPumpOff, "btnPumpOff");
            this.btnPumpOff.Name = "btnPumpOff";
            this.btnPumpOff.UseVisualStyleBackColor = true;
            this.btnPumpOff.Click += new System.EventHandler(this.btnPumpOff_Click_1);
            // 
            // btnPumpOn
            // 
            this.btnPumpOn.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnPumpOn, "btnPumpOn");
            this.btnPumpOn.Name = "btnPumpOn";
            this.btnPumpOn.UseVisualStyleBackColor = true;
            this.btnPumpOn.Click += new System.EventHandler(this.btnPumpOn_Click_1);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_FanOff);
            this.groupBox8.Controls.Add(this.btn_Fanall);
            this.groupBox8.Controls.Add(this.btn_Fan2);
            this.groupBox8.Controls.Add(this.btn_Fan1);
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.ForeColor = System.Drawing.Color.White;
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            this.groupBox8.Enter += new System.EventHandler(this.groupBox8_Enter_1);
            // 
            // btn_FanOff
            // 
            this.btn_FanOff.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btn_FanOff, "btn_FanOff");
            this.btn_FanOff.Name = "btn_FanOff";
            this.btn_FanOff.UseVisualStyleBackColor = true;
            this.btn_FanOff.Click += new System.EventHandler(this.btn_FanOff_Click);
            // 
            // btn_Fanall
            // 
            this.btn_Fanall.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btn_Fanall, "btn_Fanall");
            this.btn_Fanall.Name = "btn_Fanall";
            this.btn_Fanall.UseVisualStyleBackColor = true;
            this.btn_Fanall.Click += new System.EventHandler(this.btn_Fanall_Click);
            // 
            // btn_Fan2
            // 
            this.btn_Fan2.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btn_Fan2, "btn_Fan2");
            this.btn_Fan2.Name = "btn_Fan2";
            this.btn_Fan2.UseVisualStyleBackColor = true;
            this.btn_Fan2.Click += new System.EventHandler(this.btn_Fan2_Click);
            // 
            // btn_Fan1
            // 
            this.btn_Fan1.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btn_Fan1, "btn_Fan1");
            this.btn_Fan1.Name = "btn_Fan1";
            this.btn_Fan1.UseVisualStyleBackColor = true;
            this.btn_Fan1.Click += new System.EventHandler(this.btn_Fan1_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnLamp3);
            this.groupBox7.Controls.Add(this.btnLamp2);
            this.groupBox7.Controls.Add(this.btnLampOff);
            this.groupBox7.Controls.Add(this.btnLamp1);
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // btnLamp3
            // 
            this.btnLamp3.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnLamp3, "btnLamp3");
            this.btnLamp3.Name = "btnLamp3";
            this.btnLamp3.UseVisualStyleBackColor = true;
            this.btnLamp3.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // btnLamp2
            // 
            this.btnLamp2.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnLamp2, "btnLamp2");
            this.btnLamp2.Name = "btnLamp2";
            this.btnLamp2.UseVisualStyleBackColor = true;
            this.btnLamp2.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnLampOff
            // 
            this.btnLampOff.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnLampOff, "btnLampOff");
            this.btnLampOff.Name = "btnLampOff";
            this.btnLampOff.UseVisualStyleBackColor = true;
            this.btnLampOff.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btnLamp1
            // 
            this.btnLamp1.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnLamp1, "btnLamp1");
            this.btnLamp1.Name = "btnLamp1";
            this.btnLamp1.UseVisualStyleBackColor = true;
            this.btnLamp1.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.groupBox10.Controls.Add(this.btnCon);
            this.groupBox10.Controls.Add(this.cmbCity);
            this.groupBox10.Controls.Add(this.btnDBcon);
            this.groupBox10.Controls.Add(this.picDBoff);
            this.groupBox10.Controls.Add(this.label1);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.label2);
            this.groupBox10.Controls.Add(this.cmbComPort);
            this.groupBox10.Controls.Add(this.cmbBaudRate);
            this.groupBox10.Controls.Add(this.picDBon);
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.ForeColor = System.Drawing.Color.White;
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            this.groupBox10.Enter += new System.EventHandler(this.groupBox10_Enter);
            // 
            // cmbCity
            // 
            resources.ApplyResources(this.cmbCity, "cmbCity");
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.SelectedIndexChanged += new System.EventHandler(this.cmbCity_SelectedIndexChanged);
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Name = "label20";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label14);
            this.groupBox14.Controls.Add(this.label13);
            this.groupBox14.Controls.Add(this.label15);
            this.groupBox14.Controls.Add(this.label12);
            resources.ApplyResources(this.groupBox14, "groupBox14");
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.TabStop = false;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Name = "label14";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Name = "label13";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Name = "label15";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Name = "label12";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label16);
            this.groupBox15.Controls.Add(this.label17);
            this.groupBox15.Controls.Add(this.label18);
            this.groupBox15.Controls.Add(this.label19);
            resources.ApplyResources(this.groupBox15, "groupBox15");
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.TabStop = false;
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Name = "label16";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Name = "label17";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Name = "label18";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Name = "label19";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label25);
            this.groupBox16.Controls.Add(this.label22);
            this.groupBox16.Controls.Add(this.label23);
            this.groupBox16.Controls.Add(this.label24);
            resources.ApplyResources(this.groupBox16, "groupBox16");
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.TabStop = false;
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Name = "label25";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Name = "label22";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Name = "label23";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Name = "label24";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label28);
            this.groupBox17.Controls.Add(this.label29);
            this.groupBox17.Controls.Add(this.label30);
            this.groupBox17.Controls.Add(this.label31);
            resources.ApplyResources(this.groupBox17, "groupBox17");
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.TabStop = false;
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Name = "label28";
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Name = "label29";
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Name = "label30";
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Name = "label31";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label34);
            this.groupBox18.Controls.Add(this.label35);
            this.groupBox18.Controls.Add(this.label36);
            this.groupBox18.Controls.Add(this.label37);
            resources.ApplyResources(this.groupBox18, "groupBox18");
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.TabStop = false;
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Name = "label34";
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Name = "label35";
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Name = "label36";
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Name = "label37";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.label40);
            this.groupBox19.Controls.Add(this.label41);
            this.groupBox19.Controls.Add(this.label42);
            this.groupBox19.Controls.Add(this.label43);
            resources.ApplyResources(this.groupBox19, "groupBox19");
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.TabStop = false;
            // 
            // label40
            // 
            resources.ApplyResources(this.label40, "label40");
            this.label40.Name = "label40";
            // 
            // label41
            // 
            resources.ApplyResources(this.label41, "label41");
            this.label41.Name = "label41";
            // 
            // label42
            // 
            resources.ApplyResources(this.label42, "label42");
            this.label42.Name = "label42";
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // label43
            // 
            resources.ApplyResources(this.label43, "label43");
            this.label43.Name = "label43";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.groupBox14);
            this.groupBox20.Controls.Add(this.groupBox15);
            this.groupBox20.Controls.Add(this.groupBox19);
            this.groupBox20.Controls.Add(this.groupBox16);
            this.groupBox20.Controls.Add(this.groupBox18);
            this.groupBox20.Controls.Add(this.groupBox17);
            resources.ApplyResources(this.groupBox20, "groupBox20");
            this.groupBox20.ForeColor = System.Drawing.Color.White;
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.TabStop = false;
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label26.ForeColor = System.Drawing.SystemColors.Window;
            this.label26.Name = "label26";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chart1.BackSecondaryColor = System.Drawing.Color.Transparent;
            this.chart1.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chart1.BorderlineWidth = 3;
            chartArea1.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.White;
            chartArea1.AxisX.LineColor = System.Drawing.Color.White;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.White;
            chartArea1.AxisX.MajorGrid.LineWidth = 2;
            chartArea1.AxisX.MajorTickMark.LineColor = System.Drawing.Color.White;
            chartArea1.AxisX.MinorGrid.LineColor = System.Drawing.Color.White;
            chartArea1.AxisX.MinorTickMark.LineColor = System.Drawing.Color.White;
            chartArea1.AxisX.TitleForeColor = System.Drawing.Color.White;
            chartArea1.AxisX2.ScrollBar.Enabled = false;
            chartArea1.AxisY.LabelStyle.ForeColor = System.Drawing.Color.White;
            chartArea1.AxisY.LineColor = System.Drawing.Color.White;
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.White;
            chartArea1.AxisY.MajorTickMark.Enabled = false;
            chartArea1.AxisY.MajorTickMark.LineColor = System.Drawing.Color.White;
            chartArea1.AxisY.Maximum = 60D;
            chartArea1.AxisY.Minimum = 0D;
            chartArea1.AxisY.TitleForeColor = System.Drawing.Color.White;
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.BorderColor = System.Drawing.Color.White;
            chartArea1.CursorX.Interval = 0D;
            chartArea1.CursorX.LineWidth = 10;
            chartArea1.CursorY.LineWidth = 10;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            resources.ApplyResources(this.chart1, "chart1");
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.BorderWidth = 5;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Color = System.Drawing.Color.Red;
            series1.IsVisibleInLegend = false;
            series1.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.SuppressExceptions = true;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Name = "label38";
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chart2.BorderlineWidth = 2;
            chartArea2.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.AxisX.Interval = 2D;
            chartArea2.AxisY.IsLabelAutoFit = false;
            chartArea2.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisY.LabelStyle.ForeColor = System.Drawing.Color.White;
            chartArea2.AxisY.LineColor = System.Drawing.Color.White;
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.White;
            chartArea2.AxisY.MajorTickMark.Enabled = false;
            chartArea2.AxisY.MajorTickMark.TickMarkStyle = System.Windows.Forms.DataVisualization.Charting.TickMarkStyle.InsideArea;
            chartArea2.AxisY.Maximum = 100D;
            chartArea2.AxisY.Minimum = 0D;
            chartArea2.AxisY2.MajorGrid.LineColor = System.Drawing.Color.White;
            chartArea2.AxisY2.TitleForeColor = System.Drawing.Color.White;
            chartArea2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            legend2.Enabled = false;
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            resources.ApplyResources(this.chart2, "chart2");
            this.chart2.Name = "chart2";
            series2.BorderWidth = 5;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.IsVisibleInLegend = false;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart2.Series.Add(series2);
            // 
            // lblTodayText
            // 
            resources.ApplyResources(this.lblTodayText, "lblTodayText");
            this.lblTodayText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTodayText.ForeColor = System.Drawing.SystemColors.Window;
            this.lblTodayText.Name = "lblTodayText";
            this.lblTodayText.UseCompatibleTextRendering = true;
            this.lblTodayText.Click += new System.EventHandler(this.lblTodayText_Click);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Name = "label32";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.groupBox2);
            resources.ApplyResources(this.groupBox12, "groupBox12");
            this.groupBox12.ForeColor = System.Drawing.Color.White;
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.TabStop = false;
            // 
            // lblHumi_in
            // 
            this.lblHumi_in.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.lblHumi_in, "lblHumi_in");
            this.lblHumi_in.ForeColor = System.Drawing.Color.Blue;
            this.lblHumi_in.Name = "lblHumi_in";
            // 
            // lblTemp_in
            // 
            this.lblTemp_in.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.lblTemp_in, "lblTemp_in");
            this.lblTemp_in.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblTemp_in.Name = "lblTemp_in";
            this.lblTemp_in.Click += new System.EventHandler(this.lblTemp_in_Click);
            // 
            // TempProgressBar
            // 
            this.TempProgressBar.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.TempProgressBar.AnimationSpeed = 500;
            this.TempProgressBar.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.TempProgressBar, "TempProgressBar");
            this.TempProgressBar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TempProgressBar.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TempProgressBar.InnerMargin = 2;
            this.TempProgressBar.InnerWidth = -1;
            this.TempProgressBar.MarqueeAnimationSpeed = 2000;
            this.TempProgressBar.Name = "TempProgressBar";
            this.TempProgressBar.OuterColor = System.Drawing.Color.Gray;
            this.TempProgressBar.OuterMargin = -25;
            this.TempProgressBar.OuterWidth = 26;
            this.TempProgressBar.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.TempProgressBar.ProgressWidth = 10;
            this.TempProgressBar.SecondaryFont = new System.Drawing.Font("굴림", 36F);
            this.TempProgressBar.StartAngle = 270;
            this.TempProgressBar.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.TempProgressBar.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.TempProgressBar.SubscriptText = ".23";
            this.TempProgressBar.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.TempProgressBar.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.TempProgressBar.SuperscriptText = "°C";
            this.TempProgressBar.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.TempProgressBar.Value = 68;
            // 
            // HumiProgressBar
            // 
            this.HumiProgressBar.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.HumiProgressBar.AnimationSpeed = 500;
            this.HumiProgressBar.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.HumiProgressBar, "HumiProgressBar");
            this.HumiProgressBar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.HumiProgressBar.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.HumiProgressBar.InnerMargin = 2;
            this.HumiProgressBar.InnerWidth = -1;
            this.HumiProgressBar.MarqueeAnimationSpeed = 2000;
            this.HumiProgressBar.Name = "HumiProgressBar";
            this.HumiProgressBar.OuterColor = System.Drawing.Color.Gray;
            this.HumiProgressBar.OuterMargin = -25;
            this.HumiProgressBar.OuterWidth = 26;
            this.HumiProgressBar.ProgressColor = System.Drawing.Color.Navy;
            this.HumiProgressBar.ProgressWidth = 10;
            this.HumiProgressBar.SecondaryFont = new System.Drawing.Font("굴림", 36F);
            this.HumiProgressBar.StartAngle = 270;
            this.HumiProgressBar.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.HumiProgressBar.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.HumiProgressBar.SubscriptText = ".23";
            this.HumiProgressBar.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.HumiProgressBar.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.HumiProgressBar.SuperscriptText = "°C";
            this.HumiProgressBar.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.HumiProgressBar.Value = 68;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.lblLight_in);
            this.groupBox2.Controls.Add(this.LightProgressBar);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // lblLight_in
            // 
            this.lblLight_in.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.lblLight_in, "lblLight_in");
            this.lblLight_in.ForeColor = System.Drawing.Color.Yellow;
            this.lblLight_in.Name = "lblLight_in";
            this.lblLight_in.Click += new System.EventHandler(this.lblLight_in_Click);
            // 
            // LightProgressBar
            // 
            this.LightProgressBar.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.LightProgressBar.AnimationSpeed = 500;
            this.LightProgressBar.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.LightProgressBar, "LightProgressBar");
            this.LightProgressBar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.LightProgressBar.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LightProgressBar.InnerMargin = 2;
            this.LightProgressBar.InnerWidth = -1;
            this.LightProgressBar.MarqueeAnimationSpeed = 2000;
            this.LightProgressBar.Name = "LightProgressBar";
            this.LightProgressBar.OuterColor = System.Drawing.Color.Gray;
            this.LightProgressBar.OuterMargin = -25;
            this.LightProgressBar.OuterWidth = 26;
            this.LightProgressBar.ProgressColor = System.Drawing.Color.Khaki;
            this.LightProgressBar.ProgressWidth = 10;
            this.LightProgressBar.SecondaryFont = new System.Drawing.Font("굴림", 36F);
            this.LightProgressBar.StartAngle = 270;
            this.LightProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.LightProgressBar.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.LightProgressBar.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.LightProgressBar.SubscriptText = ".23";
            this.LightProgressBar.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.LightProgressBar.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.LightProgressBar.SuperscriptText = "°C";
            this.LightProgressBar.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.LightProgressBar.Value = 68;
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.groupBox13);
            this.groupBox11.Controls.Add(this.groupBox4);
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.ForeColor = System.Drawing.Color.White;
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            this.groupBox11.Enter += new System.EventHandler(this.groupBox11_Enter);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label7);
            this.groupBox13.Controls.Add(this.lblWaterTemp);
            this.groupBox13.Controls.Add(this.TankTempProgressBar1);
            this.groupBox13.ForeColor = System.Drawing.Color.White;
            resources.ApplyResources(this.groupBox13, "groupBox13");
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.TabStop = false;
            // 
            // lblWaterTemp
            // 
            this.lblWaterTemp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.lblWaterTemp, "lblWaterTemp");
            this.lblWaterTemp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblWaterTemp.Name = "lblWaterTemp";
            // 
            // TankTempProgressBar1
            // 
            this.TankTempProgressBar1.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.TankTempProgressBar1.AnimationSpeed = 500;
            this.TankTempProgressBar1.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.TankTempProgressBar1, "TankTempProgressBar1");
            this.TankTempProgressBar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TankTempProgressBar1.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TankTempProgressBar1.InnerMargin = 2;
            this.TankTempProgressBar1.InnerWidth = -1;
            this.TankTempProgressBar1.MarqueeAnimationSpeed = 2000;
            this.TankTempProgressBar1.Name = "TankTempProgressBar1";
            this.TankTempProgressBar1.OuterColor = System.Drawing.Color.Gray;
            this.TankTempProgressBar1.OuterMargin = -25;
            this.TankTempProgressBar1.OuterWidth = 26;
            this.TankTempProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.TankTempProgressBar1.ProgressWidth = 10;
            this.TankTempProgressBar1.SecondaryFont = new System.Drawing.Font("굴림", 36F);
            this.TankTempProgressBar1.StartAngle = 270;
            this.TankTempProgressBar1.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.TankTempProgressBar1.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.TankTempProgressBar1.SubscriptText = ".23";
            this.TankTempProgressBar1.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.TankTempProgressBar1.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.TankTempProgressBar1.SuperscriptText = "°C";
            this.TankTempProgressBar1.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.TankTempProgressBar1.Value = 68;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.Water_Level_Bar);
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // metroListView1
            // 
            resources.ApplyResources(this.metroListView1, "metroListView1");
            this.metroListView1.FullRowSelect = true;
            this.metroListView1.Name = "metroListView1";
            this.metroListView1.OwnerDraw = true;
            this.metroListView1.UseCompatibleStateImageBehavior = false;
            this.metroListView1.UseSelectable = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            resources.ApplyResources(this.listBox1, "listBox1");
            this.listBox1.Name = "listBox1";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.pictureBox1.BackgroundImage = global::project_test.Properties.Resources.title;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // picDBoff
            // 
            this.picDBoff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.picDBoff.Image = global::project_test.Properties.Resources.DBoff;
            resources.ApplyResources(this.picDBoff, "picDBoff");
            this.picDBoff.Name = "picDBoff";
            this.picDBoff.TabStop = false;
            this.picDBoff.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // picDBon
            // 
            this.picDBon.Image = global::project_test.Properties.Resources.DBon;
            resources.ApplyResources(this.picDBon, "picDBon");
            this.picDBon.Name = "picDBon";
            this.picDBon.TabStop = false;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Name = "label8";
            // 
            // Water_Level_Bar
            // 
            resources.ApplyResources(this.Water_Level_Bar, "Water_Level_Bar");
            this.Water_Level_Bar.Name = "Water_Level_Bar";
            this.Water_Level_Bar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblHumi_in);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.HumiProgressBar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblTemp_in);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.TempProgressBar);
            this.Controls.Add(this.metroListView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.lblTodayText);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox20);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.statusbar);
            this.ForeColor = System.Drawing.Color.Violet;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusbar.ResumeLayout(false);
            this.statusbar.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox_Manual.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDBoff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDBon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbComPort;
        private System.Windows.Forms.ComboBox cmbBaudRate;
        private System.Windows.Forms.Button btnCon;
        private System.Windows.Forms.RadioButton btnManual;
        private System.Windows.Forms.RadioButton btnAuto;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox picDBoff;
        private System.Windows.Forms.StatusStrip statusbar;
        private System.Windows.Forms.Button btnDBcon;
        private System.Windows.Forms.ToolStripStatusLabel Status;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox Data_listBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox picDBon;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTodayText;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_Fan1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnLamp3;
        private System.Windows.Forms.Button btnLamp2;
        private System.Windows.Forms.Button btnLampOff;
        private System.Windows.Forms.Button btnLamp1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnPumpOff;
        private System.Windows.Forms.Button btnPumpOn;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label lblHumi_in;
        private System.Windows.Forms.Label lblTemp_in;
        private CircularProgressBar.CircularProgressBar TempProgressBar;
        private CircularProgressBar.CircularProgressBar HumiProgressBar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblLight_in;
        private CircularProgressBar.CircularProgressBar LightProgressBar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label lblWaterTemp;
        private CircularProgressBar.CircularProgressBar TankTempProgressBar1;
        private System.Windows.Forms.GroupBox groupBox4;
        private VerticalProgressBar Water_Level_Bar;
        private System.Windows.Forms.Button btn_Fanall;
        private System.Windows.Forms.Button btn_Fan2;
        private System.Windows.Forms.GroupBox groupBox_Manual;
        private System.Windows.Forms.Button btn_FanOff;
        private MetroFramework.Controls.MetroListView metroListView1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
    }
}

