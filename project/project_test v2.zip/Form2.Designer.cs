﻿
namespace project_test
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox_Manual = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnPumpOff = new System.Windows.Forms.Button();
            this.btnPumpOn = new System.Windows.Forms.Button();
            this.btnManual = new System.Windows.Forms.RadioButton();
            this.btnAuto = new System.Windows.Forms.RadioButton();
            this.groupBox3.SuspendLayout();
            this.groupBox_Manual.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox3.Controls.Add(this.groupBox_Manual);
            this.groupBox3.Controls.Add(this.btnManual);
            this.groupBox3.Controls.Add(this.btnAuto);
            this.groupBox3.Location = new System.Drawing.Point(12, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(718, 506);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            // 
            // groupBox_Manual
            // 
            this.groupBox_Manual.Controls.Add(this.groupBox9);
            this.groupBox_Manual.Controls.Add(this.groupBox8);
            this.groupBox_Manual.Controls.Add(this.groupBox7);
            this.groupBox_Manual.Controls.Add(this.groupBox6);
            this.groupBox_Manual.ForeColor = System.Drawing.Color.White;
            this.groupBox_Manual.Location = new System.Drawing.Point(7, 51);
            this.groupBox_Manual.Name = "groupBox_Manual";
            this.groupBox_Manual.Size = new System.Drawing.Size(705, 435);
            this.groupBox_Manual.TabIndex = 15;
            this.groupBox_Manual.TabStop = false;
            this.groupBox_Manual.Text = "수동 제어";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button6);
            this.groupBox9.Controls.Add(this.button7);
            this.groupBox9.ForeColor = System.Drawing.Color.White;
            this.groupBox9.Location = new System.Drawing.Point(382, 32);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(100, 161);
            this.groupBox9.TabIndex = 16;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "내부 환기";
            // 
            // button6
            // 
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(13, 97);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 15;
            this.button6.Text = "Off";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(13, 44);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 14;
            this.button7.Text = "On";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button4);
            this.groupBox8.Controls.Add(this.button5);
            this.groupBox8.ForeColor = System.Drawing.Color.White;
            this.groupBox8.Location = new System.Drawing.Point(257, 32);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(100, 161);
            this.groupBox8.TabIndex = 16;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "탱크 환기";
            // 
            // button4
            // 
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(13, 97);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 15;
            this.button4.Text = "Off";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(13, 44);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 14;
            this.button5.Text = "On";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox7.Controls.Add(this.button2);
            this.groupBox7.Controls.Add(this.button3);
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Location = new System.Drawing.Point(131, 32);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(100, 161);
            this.groupBox7.TabIndex = 16;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "LED 제어";
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(13, 97);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Off";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(13, 44);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 14;
            this.button3.Text = "On";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox6.Controls.Add(this.btnPumpOff);
            this.groupBox6.Controls.Add(this.btnPumpOn);
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(7, 32);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(100, 161);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "워터 펌프 제어";
            // 
            // btnPumpOff
            // 
            this.btnPumpOff.ForeColor = System.Drawing.Color.Black;
            this.btnPumpOff.Location = new System.Drawing.Point(13, 97);
            this.btnPumpOff.Name = "btnPumpOff";
            this.btnPumpOff.Size = new System.Drawing.Size(75, 23);
            this.btnPumpOff.TabIndex = 15;
            this.btnPumpOff.Text = "Off";
            this.btnPumpOff.UseVisualStyleBackColor = true;
            // 
            // btnPumpOn
            // 
            this.btnPumpOn.ForeColor = System.Drawing.Color.Black;
            this.btnPumpOn.Location = new System.Drawing.Point(13, 44);
            this.btnPumpOn.Name = "btnPumpOn";
            this.btnPumpOn.Size = new System.Drawing.Size(75, 23);
            this.btnPumpOn.TabIndex = 14;
            this.btnPumpOn.Text = "On";
            this.btnPumpOn.UseVisualStyleBackColor = true;
            this.btnPumpOn.Click += new System.EventHandler(this.btnPumpOn_Click_1);
            // 
            // btnManual
            // 
            this.btnManual.AutoSize = true;
            this.btnManual.ForeColor = System.Drawing.Color.White;
            this.btnManual.Location = new System.Drawing.Point(90, 20);
            this.btnManual.Name = "btnManual";
            this.btnManual.Size = new System.Drawing.Size(71, 16);
            this.btnManual.TabIndex = 17;
            this.btnManual.Text = "수동제어";
            this.btnManual.UseVisualStyleBackColor = true;
            this.btnManual.CheckedChanged += new System.EventHandler(this.btnManual_CheckedChanged);
            // 
            // btnAuto
            // 
            this.btnAuto.AutoSize = true;
            this.btnAuto.Checked = true;
            this.btnAuto.ForeColor = System.Drawing.Color.White;
            this.btnAuto.Location = new System.Drawing.Point(13, 20);
            this.btnAuto.Name = "btnAuto";
            this.btnAuto.Size = new System.Drawing.Size(71, 16);
            this.btnAuto.TabIndex = 17;
            this.btnAuto.TabStop = true;
            this.btnAuto.Text = "자동제어";
            this.btnAuto.UseVisualStyleBackColor = true;
            this.btnAuto.CheckedChanged += new System.EventHandler(this.btnAuto_CheckedChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 686);
            this.Controls.Add(this.groupBox3);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox_Manual.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox_Manual;
        private System.Windows.Forms.RadioButton btnManual;
        private System.Windows.Forms.RadioButton btnAuto;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnPumpOff;
        private System.Windows.Forms.Button btnPumpOn;
    }
}