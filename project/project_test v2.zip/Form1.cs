﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using MySql.Data.MySqlClient;
using System.Xml;

namespace project_test
{
    public partial class Form1 : Form
    {
        MySqlConnection connection = new MySqlConnection("Server=localhost;Port=3307;Database=greenglory;Uid=root;Pwd=1234");

        string strURL = "http://www.kma.go.kr/weather/forecast/mid-term-xml.jsp";
        string strCity = "";



        SerialPort ComPort = new SerialPort();

        private delegate void SetTextDelegate(string getString);

        public int Water_TempValue, LampState, PumpState, FanState, TempValue, HumiValue, LightValue, Water_LevelValue, GasValue, flag;
        

        public bool mySql_Open()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot contact MySQL Server", "mySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again", "mySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    default:
                        MessageBox.Show(ex.ToString(), "mySQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
                return false;
            }
        }


        public bool mySql_Close()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }


        public Form1()
        {
            InitializeComponent();
            ComPort.DataReceived += new SerialDataReceivedEventHandler(DataReceived);



        }


        private void DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string rxd = ComPort.ReadTo("\n");
            this.BeginInvoke(new SetTextDelegate(SerialReceived), new object[] { rxd });

        }

        private void LampStateCheck(int State)
        {


            if (State == 1)
            {
                btnLampOff.BackColor = Color.DarkGray;
                btnLamp1.BackColor = Color.ForestGreen;
                btnLamp2.BackColor = Color.DarkGray;
                btnLamp3.BackColor = Color.DarkGray;
            }

            else if (State == 2)
            {
                btnLampOff.BackColor = Color.DarkGray;
                btnLamp1.BackColor = Color.DarkGray;
                btnLamp2.BackColor = Color.ForestGreen;
                btnLamp3.BackColor = Color.DarkGray;
            }

            else if (State == 3)
            {
                btnLampOff.BackColor = Color.DarkGray;
                btnLamp1.BackColor = Color.DarkGray;
                btnLamp2.BackColor = Color.DarkGray;
                btnLamp3.BackColor = Color.ForestGreen;
            }

            else
            {
                btnLampOff.BackColor = Color.ForestGreen;
                btnLamp1.BackColor = Color.DarkGray;
                btnLamp2.BackColor = Color.DarkGray;
                btnLamp3.BackColor = Color.DarkGray;
            }
        }

        private void FanStateCheck(int State)
        {


            if (State == 1)
            {
                btn_Fan1.BackColor = Color.ForestGreen;
                btn_Fan2.BackColor = Color.DarkGray;
                btn_Fanall.BackColor = Color.DarkGray;
                btn_FanOff.BackColor = Color.DarkGray;
            }

            else if (State == 2)
            {
                btn_Fan1.BackColor = Color.DarkGray;
                btn_Fan2.BackColor = Color.ForestGreen;
                btn_Fanall.BackColor = Color.DarkGray;
                btn_FanOff.BackColor = Color.DarkGray;
            }

            else if (State == 3)
            {
                btn_Fan1.BackColor = Color.DarkGray;
                btn_Fan2.BackColor = Color.DarkGray;
                btn_Fanall.BackColor = Color.ForestGreen;
                btn_FanOff.BackColor = Color.DarkGray;
            }

            else
            {
                btn_Fan1.BackColor = Color.DarkGray;
                btn_Fan2.BackColor = Color.DarkGray;
                btn_Fanall.BackColor = Color.DarkGray;
                btn_FanOff.BackColor = Color.ForestGreen;
            }
        }


        private void PumpStateCheck(int State)
        {
            if (State == 1)
            {
                btnPumpOn.BackColor = Color.ForestGreen;
                btnPumpOff.BackColor = Color.DarkGray;
            }

            else
            {
                btnPumpOn.BackColor = Color.DarkGray;
                btnPumpOff.BackColor = Color.ForestGreen;
            }


        }

        private void SerialReceived(string inString)
        {
            string InputData = inString;

            if(InputData == null)
            {
                flag = 1;
            }
            string Head = InputData.Substring(0, 1);
            string Data = InputData.Substring(1);
            Data_listBox.Items.Add(InputData);
            Data_listBox.SelectedIndex = Data_listBox.Items.Count - 1;


            if (Head == "@")
            {
                string[] PasingData = Data.Split(',');

                TempValue = (int)float.Parse(PasingData[1]);
                HumiValue = (int)float.Parse(PasingData[2]);
                LightValue = (int)float.Parse(PasingData[3]);
                GasValue = (int)float.Parse(PasingData[4]);
                Water_LevelValue = (int)float.Parse(PasingData[5]);
                Water_TempValue = (int)float.Parse(PasingData[6]);

                LampState = int.Parse(PasingData[7]);
                FanState = int.Parse(PasingData[8]);
                PumpState = int.Parse(PasingData[9]);


                LampStateCheck(LampState);
                FanStateCheck(FanState);
                PumpStateCheck(PumpState);


                lblTemp_in.Text = TempValue.ToString();
                lblHumi_in.Text = HumiValue.ToString();
                lblLight_in.Text = LightValue.ToString();
                lblWaterTemp.Text = Water_TempValue.ToString();


                TempProgressBar.Value = TempValue;
                HumiProgressBar.Value = HumiValue;
                LightProgressBar.Value = LightValue;
                Water_Level_Bar.Value = Water_LevelValue;
                label9.Text = Water_LevelValue.ToString();
                TankTempProgressBar1.Value = Water_TempValue;

                TempProgressBar.Update();
                HumiProgressBar.Update();
                LightProgressBar.Update();
                Water_Level_Bar.Update();
                TankTempProgressBar1.Update();
            }
            else if (Head == "?")
            {

                lblTemp_in.Text = "Error";
                lblHumi_in.Text = "Error";
                lblLight_in.Text = "Error";
            }
            
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if(timer2.Enabled == true)
            {
                timer2.Stop();
            }

            else
            {
                timer2.Start();
            }


            if (btnCon.Text == "Connect")
            {
                ComPort.PortName = cmbComPort.Text;
                ComPort.BaudRate = Convert.ToInt32(cmbBaudRate.Text);
                ComPort.DataBits = 8;
                ComPort.Parity = Parity.None;
                ComPort.StopBits = StopBits.One;
                ComPort.Handshake = Handshake.None;
                ComPort.Open();
                ComPort.DiscardInBuffer();
                btnCon.Text = "Close";
            }
            else
            {
                ComPort.Close();
                btnCon.Text = "Connect";
            }
        }

        public void InsertData(int Data_1, int Data_2, int Data_3, int Data_4, int Data_5, int Data_6)
        {

            MySqlCommand command = connection.CreateCommand();

            command.CommandText = "INSERT INTO save_sensor(date,time,temp,humi,lux,co2,water_level,water_temp) VALUES(@date,@time,@temp,@humi,@light,@co2,@water_level,@water_temp)";
            command.Parameters.Add("@date", MySqlDbType.VarChar).Value = DateTime.Now.ToString("yyyy-MM-dd");
            command.Parameters.Add("@time", MySqlDbType.VarChar).Value = DateTime.Now.ToString("HH:mm:ss");
            command.Parameters.Add("@temp", MySqlDbType.VarChar).Value = Data_1.ToString();
            command.Parameters.Add("@humi", MySqlDbType.VarChar).Value = Data_2.ToString();
            command.Parameters.Add("@light", MySqlDbType.VarChar).Value = Data_3.ToString();
            command.Parameters.Add("@co2", MySqlDbType.VarChar).Value = Data_4.ToString();
            command.Parameters.Add("@water_level", MySqlDbType.VarChar).Value = Data_5.ToString();
            command.Parameters.Add("@water_temp", MySqlDbType.VarChar).Value = Data_6.ToString();



            command.ExecuteNonQuery();
        }

        public void OnTimer(object sender, System.Timers.ElapsedEventArgs args)
        {
            // TODO: Insert monitoring activities here.
            Invoke((MethodInvoker)delegate
            {
                lblTodayText.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            });
        }

        public void DataGeneration()
        {
            int Graph_Value = TempValue;
            chart1.Series["Series1"].Points.Add(TempValue);

            if (chart1.Series["Series1"].Points.Count > 50)
            {
                chart1.Series["Series1"].Points.Clear();
            }

            int Graph_Value2 = HumiValue;
            chart2.Series["Series1"].Points.Add(HumiValue);

            if(chart2.Series["Series1"].Points.Count > 50)
            {
                chart2.Series["Series1"].Points.Clear();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

           //this.TopMost = true;
           this.FormBorderStyle = FormBorderStyle.None;
           this.WindowState = FormWindowState.Maximized;


            string Label_DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            lblTodayText.Text = Label_DateTime;

            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Interval = 1000;                          // 1 seconds
            timer.Elapsed += new System.Timers.ElapsedEventHandler(this.OnTimer);
            timer.Start();

            timer2.Interval = 1000;
            timer2.Stop();


            cmbCity.SelectedIndex = cmbCity.Items.Count - 1;
            cmbBaudRate.Items.Clear();
            cmbCity.Items.Add("청주");
            cmbCity.Items.Add("서울");
            cmbCity.Items.Add("인천");
            cmbCity.Items.Add("수원");
            cmbCity.Items.Add("대전");
            cmbCity.Items.Add("춘천");
            cmbCity.Items.Add("전주");
            cmbCity.Items.Add("광주");
            cmbCity.Items.Add("목포");
            cmbCity.Items.Add("여수");
            cmbCity.Items.Add("대구");
            cmbCity.Items.Add("부산");
            cmbCity.Items.Add("울산");
            cmbCity.Items.Add("제주");
            cmbCity.SelectedIndex = 0;

     



            btnAuto.Checked = true;

            cmbComPort.Items.Clear();
            var portName = System.IO.Ports.SerialPort.GetPortNames();
            cmbComPort.Items.AddRange(portName);
            cmbComPort.SelectedIndex = cmbComPort.Items.Count - 1;
            cmbBaudRate.Items.Clear();
            cmbBaudRate.Items.Add("9600");
            cmbBaudRate.Items.Add("19200");
            cmbBaudRate.Items.Add("57600");
            cmbBaudRate.Items.Add("115200");
            cmbBaudRate.SelectedIndex = 0;

            TempProgressBar.Value = 0;
            TempProgressBar.Minimum = 0;
            TempProgressBar.Maximum = 100;

            HumiProgressBar.Value = 0;
            HumiProgressBar.Minimum = 0;
            HumiProgressBar.Maximum = 100;

            LightProgressBar.Value = 0;
            LightProgressBar.Minimum = 300;
            LightProgressBar.Maximum = 1500;

            Water_Level_Bar.Value = 0;
            Water_Level_Bar.Minimum = 0;
            Water_Level_Bar.Maximum = 100;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.Close();
                ComPort.Dispose();
                ComPort = null;
            }
        }


        private void btnPumpOn_Click(object sender, EventArgs e)
        {

        }

        private void btnPumpOff_Click(object sender, EventArgs e)
        {
          
        }

        private void btnAuto_CheckedChanged(object sender, EventArgs e)
        {
            if (btnAuto.Checked == true)
            {
                groupBox_Manual.Enabled = false;
                btnPumpOn.Enabled = false;
                groupBox_Manual.ForeColor = Color.DarkGray;
            }
            else
            {
                groupBox_Manual.Enabled = true;
                btnPumpOn.Enabled = true;
                groupBox_Manual.ForeColor = Color.WhiteSmoke;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            int Data1 = TempValue;
            int Data2 = HumiValue;
            int Data3 = LightValue;
            int Data4 = GasValue;
            int Data5 = Water_LevelValue;
            int Data6 = Water_TempValue;
            
            InsertData(Data1, Data2, Data3, Data4, Data5, Data6);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (picDBoff.Visible == true)
            {
                if (mySql_Open())
                {
                    picDBon.Visible = true;
                    picDBoff.Visible = false;

                    Status.Text = "Connection Ok.";
                    btnDBcon.Enabled = true;
                }
                else
                {
                    picDBon.Visible = false;
                    picDBoff.Visible = true;


                    Status.Text = "Connection Failed.";
                    btnDBcon.Enabled = false;
                }
            }

            else
            {
                if (mySql_Close())
                {
                    picDBoff.Visible = true;
                    picDBon.Visible = false;

                    Status.Text = "dB Closing Ok.";
                }
                else
                {
                    picDBoff.Visible = true;
                    picDBon.Visible = false;

                    Status.Text = "dB Closing Failed.";
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (btnDBcon.Text == "Start")
            {
                btnDBcon.Text = "Stop";
                timer1.Start();
            }
            else
            {
                btnDBcon.Text = "Start";
                timer1.Stop();
            }
        }

        private void cmbCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                using (XmlReader xr = XmlReader.Create(strURL))
                {
                    string strMsg = "";
                    XmlWriterSettings ws = new XmlWriterSettings();
                    ws.Indent = true;
                    bool bCheck = false;
                    int iCount = 0;
                    strCity = cmbCity.Text;

                    while (xr.Read())
                    {
                        switch (xr.NodeType)
                        {
                            case XmlNodeType.Element:
                                {
                                    break;
                                }

                            case XmlNodeType.Text:
                                {
                                    if (xr.Value.Equals(strCity))
                                    {
                                        bCheck = true;
                                    }

                                    if (bCheck)
                                    {
                                        DateTime dt;
                                        bool b = DateTime.TryParse(xr.Value.ToString(), out dt);
                                        if (b)
                                        {
                                            strMsg += "/";
                                        }

                                        strMsg += xr.Value + ",";
                                        iCount += 1;
                                        if (iCount > 36)
                                        {
                                            bCheck = false;
                                        }
                                    }

                                    break;
                                }

                            case XmlNodeType.XmlDeclaration:
                                {
                                    break;
                                }

                            case XmlNodeType.ProcessingInstruction:
                                {
                                    break;
                                }

                            case XmlNodeType.Comment:
                                {
                                    break;
                                }

                            case XmlNodeType.EndElement:
                                {
                                    break;
                                }

                        }
                    }

                    string[] strTmp = strMsg.Split('/');

                    string[] strWh1 = strTmp[1].Split(',');
                    label12.Text = strWh1[0];
                    label13.Text = "MIN :" + strWh1[2] + "℃";
                    label14.Text = "MAX :" + strWh1[3] + "℃";
                    label15.Text = strWh1[1];

                    string[] strWh2 = strTmp[2].Split(',');
                    label19.Text = strWh2[0];
                    label17.Text = "MIN :" + strWh2[2] + "℃";
                    label16.Text = "MAX :" + strWh2[3] + "℃";
                    label18.Text = strWh2[1];

                    string[] strWh3 = strTmp[3].Split(',');
                    label25.Text = strWh3[0];
                    label23.Text = "MIN :" + strWh3[2] + "℃";
                    label22.Text = "MAX :" + strWh3[3] + "℃";
                    label24.Text = strWh3[1];

                    string[] strWh4 = strTmp[4].Split(',');
                    label31.Text = strWh4[0];
                    label29.Text = "MIN :" + strWh4[2] + "℃";
                    label28.Text = "MAX :" + strWh4[3] + "℃";
                    label30.Text = strWh4[1];

                    string[] strWh5 = strTmp[5].Split(',');
                    label37.Text = strWh5[0];
                    label35.Text = "MIN :" + strWh5[2] + "℃";
                    label34.Text = "MAX :" + strWh5[3] + "℃";
                    label36.Text = strWh5[1];

                    string[] strWh6 = strTmp[6].Split(',');
                    label43.Text = strWh6[0];
                    label41.Text = "MIN :" + strWh6[2] + "℃";
                    label40.Text = "MAX :" + strWh6[3] + "℃";
                    label42.Text = strWh6[1];

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            DataGeneration();
        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void lblTodayText_Click(object sender, EventArgs e)
        {

        }

        private void groupBox10_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox8_Enter(object sender, EventArgs e)
        {

        }

        private void TempProgressBar_Click(object sender, EventArgs e)
        {

        }

        private void LightProgressBar_Click(object sender, EventArgs e)
        {

        }

        private void HumiProgressBar_Click(object sender, EventArgs e)
        {

        }

        private void circularProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox_Manual_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void lblWaterLevel_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

                if (ComPort.IsOpen)
                {
                    ComPort.WriteLine("#F:4");
                }
        }

        private void groupBox11_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox8_Enter_1(object sender, EventArgs e)
        {

        }

        private void groupBox9_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#L:1");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#L:2");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lblTemp_in_Click(object sender, EventArgs e)
        {

        }

        private void lblLight_in_Click(object sender, EventArgs e)
        {

        }

        private void btn_FanOff_Click(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#F:0");
            }
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#L:3");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#L:0");
            }
        }

        private void btnPumpOn_Click_1(object sender, EventArgs e)
        {

            if (ComPort.IsOpen)
            {
                
                    ComPort.WriteLine("#P:1");
                
            }
        }

        private void btnPumpOff_Click_1(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#P:0");
            }
        }



        private void groupBox9_Enter_1(object sender, EventArgs e)
        {

        }

        private void btn_Fanall_Click(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#F:3");
            }
        }

        private void btn_Fan1_Click(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#F:1");
            }
        }

        private void btn_Fan2_Click(object sender, EventArgs e)
        {
            if (ComPort.IsOpen)
            {
                ComPort.WriteLine("#F:2");
            }
        }
    }
}
